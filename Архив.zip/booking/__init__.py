default_app_config = "booking.apps.BookingConfig"
