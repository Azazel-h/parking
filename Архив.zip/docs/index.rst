Индексы и таблицы
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

Документация Parking
======================

.. toctree::
   :maxdepth: 3
   :caption: Views

   ./views.rst

.. toctree::
   :maxdepth: 3
   :caption: Forms

   ./forms.rst

.. toctree::
   :maxdepth: 3
   :caption: Models

   ./models.rst